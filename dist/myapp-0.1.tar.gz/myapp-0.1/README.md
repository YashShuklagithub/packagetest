# HelloWorld Django Package

A simple Django app that returns "Hello, World!" when accessed.

## Installation

```bash
pip install helloworld
